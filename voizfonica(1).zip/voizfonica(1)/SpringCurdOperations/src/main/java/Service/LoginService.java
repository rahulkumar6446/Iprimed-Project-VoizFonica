package Service;

import org.springframework.stereotype.Service;

@Service
public class LoginService {
	public boolean validateUser(String name, String password) {
		return name.equalsIgnoreCase("rahul") && password.equalsIgnoreCase("rahul");
	}

	public boolean validateUserDB(String name, String password) {
		// try db connect and call dao
		if (true) {
	   return true;
		} else {
	   return false;
		}

	}
}