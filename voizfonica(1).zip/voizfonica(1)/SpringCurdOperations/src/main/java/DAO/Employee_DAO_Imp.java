package DAO;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import Model.Employee;




@Repository
public class Employee_DAO_Imp  implements Employee_DAO{

	@Autowired
	private SessionFactory sessionFactory;
	
	public boolean saveEmployee(Employee employee) {
		boolean status=false;
		try {
			sessionFactory.getCurrentSession().save(employee);
			status=true;
			System.out.println("Record Added Successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	
	@Override
	public List<Employee> getEmployees() {
		Session currentSession = sessionFactory.getCurrentSession();
		Query<Employee> query=currentSession.createQuery("from Employee", Employee.class);
		List<Employee> list=query.getResultList();
		return list;
	}
	//delete
	@Override
	
	public Employee deteleEmployee(Integer id) {
		Session currentSession = sessionFactory.getCurrentSession();
		Employee employee=new Employee();
		employee.setId(id);
		sessionFactory.getCurrentSession().delete(employee);
		//Query<Employee> query=currentSession.createQuery("from Employee", Employee.class);
		//List<Employee> list=query.getResultList();
		return null;
	}
	//edit
	@Override
	public Employee getEmployeesById(Integer id) {
		Session currentSession = sessionFactory.getCurrentSession();
		Query<Employee> query=currentSession.createQuery("from Employee where id=:id");
		query.setParameter("id",id);
	    Employee e=(Employee) query.list().get(0);
		return e;
	
	}

}
