package Controller;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import Model.Employee;

import Service.Employee_Service;




@RestController
@CrossOrigin
//@RequestMapping(value = "/rest")
@ComponentScan
public class MyRestController implements WebMvcConfigurer {
	
	@Autowired
	private Employee_Service employeeservice;

	@RequestMapping("/hello") // end point URL REST API crud ( creat:POST read:GET update:PUT delete:DELETE)
	public String showForm() {
		return "<marquee><h1>hello Prodapt B18</h1></marquee>";
		
	}
	
	@RequestMapping("/") // end point URL REST API crud ( creat:POST read:GET update:PUT delete:DELETE)
	public String hi() {
		return "<marquee><h1>hello Prodapt Batch 18</h1></marquee>";
		
	}
	
	
	//Will Add CRUD here 1 by 1
	
		//Create
	
	@PostMapping("save-employee1")
	public boolean saveEmployees(@RequestBody Employee employee) {
		return employeeservice.saveEmployee(employee);

	}
	
	

	@RequestMapping(value ="/enroll",method = RequestMethod.GET)
	public String newRegistration(ModelMap model) {
		Employee employee = new Employee();
		model.addAttribute("employee", employee);
		return "enroll";
	}
	
	@RequestMapping(value ="/save",method = RequestMethod.POST)
	public String saveRegistration(@Valid Employee employee,
			BindingResult result, ModelMap model,RedirectAttributes redirectAttributes) {

		if (result.hasErrors()) {
			return "enroll";//will redirect to viewemp request mapping  
		}
		employeeservice.saveEmployee(employee);		
		//redirectAttributes.addFlashAttribute("message", "Student " + student.getFirstName()+" "+student.getLastName() + " saved");
		return "redirect:/viewemployees";//will redirect to viewemp request mapping  
	}
	
	
	
	
	
	
	
	
	
	    //Read
	
	@RequestMapping(method = RequestMethod.GET, value = "logindetails")
	public List<Employee> allstudents() {
		return employeeservice.getEmployees();
	}
	
	
		
		@RequestMapping("/viewemployees")  
	    public ModelAndView viewstudents(){  
	        List<Employee> list=employeeservice.getEmployees();
	        return new ModelAndView("viewstudents","list",list);   //Amazing
	        
	        //What is ModelAndView in Spring 
	        //Delete
	    } 
		 @GetMapping("/employee/{employeeid}")
		  public ModelAndView deleteemployee(@PathVariable("employeeid") int employeeid) {
			 Employee emp =  employeeservice.deleteEmployee(employeeid);
			 return new ModelAndView("viewstudents","employee",emp);   //Amazing			 
		 }
		 @GetMapping("/fetchEmployee/{employeeid}")
		  public ModelAndView getEmployeeById(@PathVariable("employeeid") int employeeid) {
			 Employee emp =  employeeservice.getEmployeeById(employeeid);
			 return new ModelAndView("editEmployee","employee",emp);   //Amazing			 
		 }
				


}