package Config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCurdOperationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCurdOperationsApplication.class, args);
		System.out.println("connected");
	}

}
